import cv2
import numpy as np
from time import sleep

# Minimum rectangle dimensions for detection
largura_min = 40
altura_min = 40

# Position of the counting line and pixel offset margin
offset = 6
pos_linha = 550
delay = 60  # Frame delay for processing

detec = []
carros = 0

def pega_centro(x, y, w, h):
    """Calculate the center point of a rectangle"""
    cx = x + int(w / 2)
    cy = y + int(h / 2)
    return cx, cy

# Load video
cap = cv2.VideoCapture('video.mp4')

# Background subtractor (updated to MOG2)
subtracao = cv2.createBackgroundSubtractorMOG2(history=100, varThreshold=40, detectShadows=True)

while True:
    ret, frame1 = cap.read()
    if not ret:
        break

    tempo = float(1 / delay)
    sleep(tempo)

    # Pre-processing
    grey = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(grey, (3, 3), 5)

    # Background subtraction
    img_sub = subtracao.apply(blur)

    # Morphological operations to remove noise
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    mask = cv2.morphologyEx(img_sub, cv2.MORPH_OPEN, kernel, iterations=2)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)

    # Optional threshold to ensure binary output
    _, mask = cv2.threshold(mask, 200, 255, cv2.THRESH_BINARY)

    # Find contours
    contornos, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # Draw counting line
    cv2.line(frame1, (25, pos_linha), (1200, pos_linha), (255, 127, 0), 3)

    for (i, c) in enumerate(contornos):
        (x, y, w, h) = cv2.boundingRect(c)
        validar_contorno = (w >= largura_min) and (h >= altura_min)
        if not validar_contorno:
            continue

        # Draw rectangle around detected object
        cv2.rectangle(frame1, (x, y), (x + w, y + h), (0, 255, 0), 2)

        centro = pega_centro(x, y, w, h)
        detec.append(centro)
        cv2.circle(frame1, centro, 4, (0, 0, 255), -1)

        for (cx, cy) in detec:
            if pos_linha - offset < cy < pos_linha + offset:
                carros += 1
                cv2.line(frame1, (25, pos_linha), (1200, pos_linha), (0, 127, 255), 3)
                detec.remove((cx, cy))
                print("Car detected: " + str(carros))

    # Display count on screen
    cv2.putText(frame1, "VEHICLE COUNT: " + str(carros), (450, 70),
                cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 255), 5)

    # Show original video and detection mask
    cv2.imshow("Video Original", frame1)
    cv2.imshow("Detectar", mask)

    if cv2.waitKey(1) == 27:  # Press ESC to exit
        break

cap.release()
cv2.destroyAllWindows()
